# Pythonflix
name = "Top Gun Maverick"
yearLaunch = 2023
noteMovie = 9.5
planIncluded = False

print(name)
print(yearLaunch)

print(type(name))
print(type(yearLaunch))
print(type(noteMovie))
print(type(planIncluded))