movieName = "Top Gun"
movieName2 = "top Gun"
print(movieName == movieName2) # Case Sensitive

movieDescription = """
    Top Gun Maverick é um filme de aviação e aventura
muito consagrado na indústria
"""
print(movieName)
# 1- Multiplicação de Strings
line = "="
print(line*50)
print(movieDescription)

# 2- Procurar uma palavra dentro de um texto
print("Top" in movieName)
print("ação" in movieName)
